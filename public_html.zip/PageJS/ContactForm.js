const emailSend=()=>{
    Email.send({
        Host : "smtp.elasticemail.com",
        Username : "waywheel03@gmail.com",
        Password : "97E6CAA9FAA690F0D787A183B66B24BA7495",
        To : 'contactus@waywheel.in',
        From : document.getElementById('email').value,
        Subject : "WayWheel Contact Enquiry",
        Body : "This mail is from the Contact Us Page"
    }).then(
      message => alert("Success!")
    );
}