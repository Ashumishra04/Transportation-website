let accordianUser=document.getElementById('accordionUser');
let accordianDriver=document.getElementById('accordionDriver');





const UserData=[
    {
        ques:"Are toll charges and parking charges included in the fare?",
        ans:"Toll & Parking Charges are not included in the fare. Such charges shall be paid by the sender/ consignor directly to the driver assigned.",
        id:"One"
    },
    {
        ques:"Who is responsible for generation and maintenance of E-way bills during transit?",
        ans:"It is the responsibility of the customer to generate the E-way bill and provide a copy of the same to the driver partner.",
        id:"Two"
    },
    {
        ques:"What happens if a trip is canceled? What are the cancellation charges and policy?",
        ans:"You can cancel the trip only before sharing the OTP to the driver to start the trip. <br/>We expect our customers to respect the policy.",
        id:"Three"
    },
    {
        ques:"How do I contact the WayWheel support team?",
        ans:"Go to “Account” section in the app and click on Call Us. ",
        id:"Four"
    },
    {
        ques:"Can I schedule multiple drop locations at once?",
        ans:"Certainly, you may schedule bookings for multiple stops up to 4 multiple locations. Additional charges corresponding to each additional point of delivery or pickup will be calculated accordingly.",
        id:"Five"
    },
    {
        ques:"Is live tracking available? ",
        ans:"Yes. You can track the vehicle in real time.",
        id:"Six"
    },
    {
        ques:"What are the restrictions on the types of products I can ship?",
        ans:"‘Prohibited Items’ means any goods or materials, the carriage of which is prohibited by Applicable Law.",
        id:"Seven"
    },
    {
        ques:"Is over-loading allowed?",
        ans:"No. Overloading is not allowed. Only loading the vehicle according to the RTO (Regional Transport Office) approved vehicle capacity is permitted. Overloading a vehicle can cause damage to the vehicle, put the safety of the passengers and other driver partners on the road at risk and is also illegal.",
        id:"Eight"
    },
    {
        ques:"Can I check my all past bookings?",
        ans:"Yes. You can check your all past bookings and download the invoice. Go to Order section in the app to view all the past bookings. ",
        id:"Nine"
    },
    {
        ques:"Whether GST is charged on the services?",
        ans:"WayWheel does not levy GST on its services. According to GST regulations, transportation services provided by GTA (Goods Transport Agency) are exempted if they are supplied to an unregistered person. However, if the services are supplied to a registered person, the customer is liable to pay GST under the Reverse Charge Mechanism.",
        id:"Ten"
    },
    {
        ques:"What is Reverse Charge Mechanism? ",
        ans:"GST is to be paid by the customer availing the services.",
        id:"Eleven"
    },
    {
        ques:"Is there any service guarantee?",
        ans:"We would like to assure you of the accuracy of our ETA & the estimated travel time. However, given the unpredictable nature of traffic & road conditions, we do not provide any service guarantee.",
        id:"Twelve"
    },
    {
        ques:"Are the customer's goods insured by WayWheel?",
        ans:"No the goods are not insured. Our rates do not include any charges towards insurance. But the customer should take insurance for goods being shipped.",
        id:"Thirteen"
    },
    {
        ques:"Can a customer purchase an insurance on WayWheel's platform?",
        ans:"We do not offer this facility as of now.",
        id:"Fourteen"
    },
    {
        ques:"What is the process in case of damage/loss/theft of goods?",
        ans:"If the customer has obtained insurance for their shipment, they are required to notify us of their intent to file an insurance claim and follow the subsequent instructions provided by their insurer. Upon request, we can assist in the survey process initiated by the customer's insurer. Additionally, we are able to issue a Certificate of Facts, a crucial document necessary for insurance claims.",
        id:"Fifteen"
    },
    
    
];

const DriverData=[
    {
        ques:"How can I attach my Mini Truck, 3-wheeler in WayWheel?",
        ans:"Becoming a WayWheel partner and affiliating your Mini Truck, 3-Wheeler with us is a straightforward process. You can accomplish it through three simple steps from the convenience of your home:<br/><ul><li>Download the WayWheel Partner Driver App.</li><li>Register and submit all required documents through the app.</li><li>Once the verification of documents and other procedures is completed, you will be approved.</li><li>Upon approval, you can commence receiving trip assignments promptly.</li><ul/>",
        id:"One"
    },
    {
        ques:"How can I attach my two-wheeler in WayWheel?",
        ans:"Obtain a bike delivery job in three simple steps:<br/><ul><li>Download the WayWheel Partner Driver App.</li><li>Register and submit all required documents through the app.</li><li>Once the verification of documents and other procedures is completed, you will be approved.</li><li>Upon approval, you can commence receiving trip assignments promptly.</li></ul>",
        id:"Two"
    },
    {
        ques:"What documents and permits do I need to on-board WayWheel?",
        ans:"For commercial vehicle attachment following documents are required: RC book | Fitness certificate | Insurance | Pollution Control | Owner/Driver documents: Driving License | PAN card | Bank Details | Address Proof",
        id:"Three"
    },
    {
        ques:"Is training available? ",
        ans:"Yes. Our Team will get in touch with you incase you need any kind of assistance. ",
        id:"Four"
    },
    {
        ques:"Is there any registration fee to join WayWheel?",
        ans:"WayWheel charges nominal fees at the time of on-boarding for vehicle attachment. Fee varies as per the vehicle type.",
        id:"Five"
    },
    {
        ques:"Which type of vehicle one can attach to WayWheel?",
        ans:"You can attach 2 wheelers such as bike and scooter, and commercial vehicles with carrying capacity of 1 ton, 2 ton, and 3 ton for our On-Demand Services.",
        id:"Six"
    },
    {
        ques:"How much you can earn per week?",
        ans:"Your earnings are dependent on the time you spend on WayWheel platform. Longer engagement with the platform lead to more trips which in turn ensures high earning.",
        id:"Seven"
    },
    {
        ques:"How I can check my earning & payouts?",
        ans:"WayWheel has an advanced driver app which provides all details pertaining to daily earning and payouts.",
        id:"Eight"
    },
    {
        ques:"Can I refer my friends and colleagues to join WayWheel?",
        ans:"Yes! We encourage our driver partners to promote WayWheel among their peers and refer them to join us. In return they deserve a goodwill bonus on each successful on-boarding of all vehicle types with carrying capacity of 1 ton, 2 ton and 3 ton. *Subject to Refer& Earn Scheme ",
        id:"Nine"
    },
    {
        ques:"I have a query. How I can get in touch with WayWheel?",
        ans:"For any query, you can visit our nearest local office or reach out to us at +91 9599224722. Contact us option is also available on the WayWheel Driver Partner App.",
        id:"Ten"
    }
]


const faq=()=>{
    UserData.map((i)=>{
        
        let accordianData=document.createElement('div');
        accordianData.classList.add('accordion-item');
        accordianData.style.width="90vw"
        accordianData.innerHTML= `   <h3 data-aos="fade-down" class="accordion-header" id="heading${i.id}">
            <button style="background-color: #083962;color:aliceblue;height:12vh;font-size:3vh;box-shadow:none;" class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse${i.id}" aria-expanded="false" aria-controls="collapse${i.id}">
             <p class="faq-ques"> ${i.ques}</p>
            </button>
          </h2>
          <div id="collapse${i.id}" class="accordion-collapse collapse" aria-labelledby="heading${i.id}" data-bs-parent="#accordionExample">
            <div style="background-color:#E6F0F7;" class="accordion-body">
              <p class="faq-ans">${i.ans}
</p>            </div>
          </div>`

          accordianUser.appendChild(accordianData);

        
    })
    DriverData.map((i)=>{
        
        let accordianData=document.createElement('div');
        accordianData.classList.add('accordion-item');
        accordianData.style.width="90vw"
        accordianData.innerHTML= `   <h3 data-aos="fade-down" class="accordion-header" id="heading${i.id}">
            <button style="background-color: #083962;color:aliceblue;height:12vh;font-size:3vh;box-shadow:none;" class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse${i.id}" aria-expanded="false" aria-controls="collapse${i.id}">
              <p class="faq-ques">${i.ques}</p>
            </button>
          </h2>
          <div id="collapse${i.id}" class="accordion-collapse collapse" aria-labelledby="heading${i.id}" data-bs-parent="#accordionExample">
            <div style="background-color:#E6F0F7;" class="accordion-body">
             <p class="faq-ans"> ${i.ans}</p>
            </div>
          </div>`

          accordianDriver.appendChild(accordianData);

        
    })

    
}

faq()