let accordian=document.getElementById('accordionExample');





const FaqData=[
    {
        ques:"Are the customer's goods insured by WayWheel?",
        ans:"No the goods are not insured. Our rates do not include any charges towards insurance. But the customer should take insurance for goods being shipped.",
        id:"One"
    },
    {
        ques:"How do I use WayWheel App",
        ans:"To initiate streamlined logistics services via WayWheel, adhere to these straightforward instructions:<br><br>1.Download the WayWheel app.<br>2.Select the desired service.<br>3.Specify both pick-up and delivery locations.<br>4.Include additional stops if necessary.<br>5.Choose the suitable vehicle type according to your needs (motorcycle, three-wheeler, or truck).<br>6.Indicate the type of goods being transported.<br>7.Select your preferred payment method.Confirm your booking by clicking 'Book Now', after which your vehicle will reach at your pick up location",
        id:"Two"
    },
    {
        ques:"Is live tracking available?",
        ans:"Yes. You can track the vehicle in real time.",
        id:"Three"
    },
    {
        ques:"How do I contact the WayWheel support team?",
        ans:"Go to “Account” section in the app and click on Call Us.",
        id:"Four"
    },
    {
        ques:"Things that can be delivered through WayWheel",
        ans:"Everything that you wish to. However, WayWheel does not deliver item(s) which are prohibited by law.",
        id:"Five"
    }
    
];




const faq=()=>{
    FaqData.map((i)=>{
        
        let accordianData=document.createElement('div');
        accordianData.classList.add('accordion-item');
        accordianData.style.width="90vw"
        accordianData.innerHTML= `   <h3 data-aos="fade-down" class="accordion-header" id="heading${i.id}">
            <button style="background-color: #083962;color:aliceblue;height:12vh;font-size:3vh;box-shadow:none;" class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse${i.id}" aria-expanded="false" aria-controls="collapse${i.id}">
             <p  class="faq-ques" >${i.ques}</p> 
            </button>
          </h2>
          <div id="collapse${i.id}" class="accordion-collapse collapse" aria-labelledby="heading${i.id}" data-bs-parent="#accordionExample">
            <div style="background-color:#E6F0F7;" class="accordion-body">
              <p class="faq-ans">${i.ans}</p>
            </div>
          </div>`

          accordian.appendChild(accordianData);

        
    })

    
}

faq()