const  BlogData=[
    {
      img:"../assets/blog1.svg",
      title:"INSTRUCTIONS FOR REGISTERED DRIVERS DELIVERING GOODS FROM AN ONLINE AGGREGATOR PLATFORM",
      date:"By Waywheel on 16/7/24",
      desc:"Registered drivers typically receive specific instructions when delivering goods from an online aggregator platform to ensure efficient and reliable service.",
      time:"4 min read",
      path:"INSTRUCTIONS-FOR-REGISTERED-DRIVERS-DELIVERING-GOODS-FROM-AN-ONLINE-AGGREGATOR-PLATFORM.html"
    },
    {
      img:"../assets/blog2.jpeg",
      title:"THE FUTURE OF URBAN INTRA-CITY LOGISTICS",
      date:"By Waywheel on 18/7/24",
      desc:"The ease of developing technologies for urban intra-city logistics demands varies depending on the specific technology",
      time:"3 min read",
      path:"The-future-of-Urban-intra-city-logistics.html"
    },
    {
      img:"../assets/blog3.jpeg",
      title:"DELIVERY STRATEGY FOR YOUR BUSINESS",
      date:"By Waywheel on 23/7/24",
      desc:"By understanding your customers, offering diverse delivery options, optimising your logistics network, selecting WayWheel as your  reliable partners, and leveraging technology, you can significantly improve your delivery performance and drive business growth.",
      time:"2 min read",
      path:"Delivery-Strategy-For-Your-Business.html"
    },
    {
      img:"../assets/blog1.svg",
      title:"Connecting Customers and Delivery Partners: The WayWheel™ Advantage",
      date:"By Waywheel on 23/7/24",
      desc:"In the today’s fast-changing world, reliable transportation services are more important than ever. No matter if you are a customer who is looking for sending small parcels across a town or you're planning a complete home relocation, Way Wheel steps up to become your most important partner",
      time:"2 min read",
      path:"Connecting-Customers-and-Delivery-Partners_The-WayWheel-Advantage.html"
    },
    {
      img:"../assets/blog1.svg",
      title:"Choosing the Right Delivery Service for Your Business: Avoiding Common Mistakes",
      date:"By Waywheel on 23/7/24",
      desc:"Selecting the right delivery service is a crucial decision for any business that relies on timely and reliable transportation of goods. Whether you're a small e-commerce store or a large retailer, your choice can significantly impact customer satisfaction and operational efficiency. ",
      time:"2 min read",
      path:"Choosing-the-Right-Delivery-Service-for-Your-Business_Avoiding-Common-Mistakes.html"
    }
  ]


let BlogCard=document.getElementById('blogContainer');


const blog= ()=>{
  
 
         BlogData.map((i)=>{
          let card= document.createElement('div');
          card.classList.add=("bcard");
            card.innerHTML=`  

            <div class="blog-card" >
            
                <div class='img'>
                  <img src="${i.img}" alt="" />
                 
                 </div>
                 <div class='title'>${i.title}</div>  
                 <h6>${i.date}</h6>
                 <p>${i.desc}</p>
                 <div class="flex">
                 <span>${i.time}</span>
                 <a href=${i.path} >view more</a>
                 </div></div>
       
           
           `
           BlogCard.appendChild(card);
        })

}
blog();