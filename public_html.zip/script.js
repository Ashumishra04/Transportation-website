let accordian=document.getElementById('accordionExample');





const FaqData=[
    {
        ques:"Are toll charges and parking charges included in the fare?",
        ans:"Toll & Parking Charges are not included in the fare. Such charges shall be paid by the sender/ consignor directly to the driver assigned.",
        id:"One"
    },
    {
        ques:"What documents and permits do I need to on-board WayWheel?",
        ans:"For commercial vehicle attachment following documents are required: RC book | Fitness certificate | Insurance | Pollution Control | Owner/Driver documents: Driving License | PAN card | Bank Details | Address Proof",
        id:"Two"
    },
    {
        ques:"Is there any registration fee to join WayWheel?",
        ans:"WayWheel charges nominal fees at the time of on-boarding for vehicle attachment. Fee varies as per the vehicle type.",
        id:"Three"
    },
    {
        ques:"Which type of vehicle one can attach to WayWheel?",
        ans:"You can attach 2 wheelers such as bike and scooter, and commercial vehicles with carrying capacity of 1 ton, 2 ton, and 3 ton for our On-Demand Services.",
        id:"Four"
    },
    {
        ques:"How much you can earn per week?",
        ans:"Your earnings are dependent on the time you spend on WayWheel platform. Longer engagement with the platform lead to more trips which in turn ensures high earning.",
        id:"Five"
    }
    
];




const faq=()=>{
    FaqData.map((i)=>{
        
        let accordianData=document.createElement('div');
        accordianData.classList.add('accordion-item');
        accordianData.style.width="95vw"
        accordianData.innerHTML= `   <h3 data-aos="fade-down" class="accordion-header" id="heading${i.id}">
            <button style="background-color: #083962;color:aliceblue;height:12vh;font-size:3vh;box-shadow:none;" class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse${i.id}" aria-expanded="false" aria-controls="collapse${i.id}">
                <p class="faq-ques" >${i.ques}</p> 
            </button>
          </h2>
          <div id="collapse${i.id}" class="accordion-collapse collapse" aria-labelledby="heading${i.id}" data-bs-parent="#accordionExample">
            <div style="background-color:#E6F0F7;" class="accordion-body">
              <p  class="faq-ans" >${i.ans}</p>
            </div>
          </div>`

          accordian.appendChild(accordianData);

        
    })

    
}

faq()